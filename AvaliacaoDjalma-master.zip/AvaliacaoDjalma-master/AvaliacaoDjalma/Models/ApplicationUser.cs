﻿using Microsoft.AspNetCore.Identity;

namespace AvaliacaoDjalma.Models
{
    public class ApplicationUser
    {
        public string UserNameId { get; set; }
        public string UserPass { get; set; }
    }
}
